package com.example.whatook.DBH;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DBATags {

    private DBHTags dbHelper;
    private SQLiteDatabase database;

    public DBATags(Context context){
        dbHelper = new DBHTags(context.getApplicationContext());
    }

    public DBATags open(){
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        dbHelper.close();
    }

    private Cursor getAllEntries(){
        String[] columns = new String[] {DBHTags.COLUMN_ID, DBHTags.COLUMN_NAME};
        return  database.query(DBHTags.TABLE, columns, null, null, null, null, null);
    }

    public List<Tag> getTags(){
        ArrayList<Tag> tags = new ArrayList<>();
        Cursor cursor = getAllEntries();
        while (cursor.moveToNext()){
            long id = cursor.getLong(cursor.getColumnIndex(DBHTags.COLUMN_ID));
            String name = cursor.getString(cursor.getColumnIndex(DBHTags.COLUMN_NAME));
            tags.add(new Tag(id, name));
        }
        cursor.close();
        return tags;
    }

    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, DBHTags.TABLE);
    }

    public long insert(Tag tag){

        ContentValues cv = new ContentValues();
        cv.put(DBHTags.COLUMN_NAME, tag.getName());

        return database.insert(DBHTags.TABLE, null, cv);
    }

    public long delete(long Id){

        String whereClause = "Id = ?";
        String[] whereArgs = new String[]{String.valueOf(Id)};
        return database.delete(DBHTags.TABLE, whereClause, whereArgs);
    }

    public long update(Tag tag){

        String whereClause = DBHTags.COLUMN_ID + "=" + String.valueOf(tag.getId());
        ContentValues cv = new ContentValues();
        cv.put(DBHTags.COLUMN_NAME, tag.getName());
        return database.update(DBHTags.TABLE, cv, whereClause, null);
    }
}