package com.example.whatook.DBH;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DBAUserSubscriptions {

    private DBHUserSubscriptions dbHelper;
    private SQLiteDatabase database;

    public DBAUserSubscriptions(Context context){
        dbHelper = new DBHUserSubscriptions(context.getApplicationContext());
    }

    public DBAUserSubscriptions open(){
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        dbHelper.close();
    }

    private Cursor getAllEntries(){
        String[] columns = new String[] {DBHUserSubscriptions.COLUMN_ID, DBHUserSubscriptions.COLUMN_USER_ID1, DBHUserSubscriptions.COLUMN_USER_ID2};
        return  database.query(DBHUserSubscriptions.TABLE, columns, null, null, null, null, null);
    }

    public List<UserSubscription> getUserSubscription(long userId){
        ArrayList<UserSubscription> us = new ArrayList<>();
        String query = String.format("SELECT * FROM %s WHERE %s=?", DBHUserSubscriptions.TABLE, DBHUserSubscriptions.COLUMN_USER_ID1);
        Cursor cursor = database.rawQuery(query, new String[]{ String.valueOf(userId)});
        while (cursor.moveToNext()){
            long id = cursor.getLong(cursor.getColumnIndex(DBHUserSubscriptions.COLUMN_ID));
            long userId2 = cursor.getLong(cursor.getColumnIndex(DBHUserSubscriptions.COLUMN_USER_ID2));
            us.add(new UserSubscription(id, userId, userId2));
        }
        cursor.close();
        return us;
    }

    public long getCount(long userId){
        String select = String.format("%s = ?", DBHUserSubscriptions.COLUMN_USER_ID2);
        return DatabaseUtils.queryNumEntries(database, DBHUserSubscriptions.TABLE, select, new String[]{ String.valueOf(userId)});
    }

    public long insert(UserSubscription us){

        ContentValues cv = new ContentValues();
        cv.put(DBHUserSubscriptions.COLUMN_USER_ID1, us.getSubscriberId());
        cv.put(DBHUserSubscriptions.COLUMN_USER_ID2, us.getUserId());

        return database.insert(DBHUserSubscriptions.TABLE, null, cv);
    }

    public long delete(long Id){

        String whereClause = "Id = ?";
        String[] whereArgs = new String[]{String.valueOf(Id)};
        return database.delete(DBHUserSubscriptions.TABLE, whereClause, whereArgs);
    }
}