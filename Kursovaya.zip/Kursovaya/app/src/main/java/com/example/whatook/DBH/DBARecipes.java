package com.example.whatook.DBH;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DBARecipes {

    private Recipes dbHelper;
    private SQLiteDatabase database;
    private Context context;

    public DBARecipes(Context context){
        this.context = context.getApplicationContext();
        dbHelper = new Recipes(context.getApplicationContext());
    }

    public DBARecipes open(){
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        dbHelper.close();
    }

    private Cursor getAllEntries(){
        String[] columns = new String[] {Recipes.COLUMN_ID, Recipes.COLUMN_USER_ID, Recipes.COLUMN_NAME, Recipes.COLUMN_TIME_TO_COOK,
                Recipes.COLUMN_TEXT, Recipes.COLUMN_LIKES, Recipes.COLUMN_USER_VISIBLE};
        return database.query(Recipes.TABLE, columns, null, null, null, null, null);
    }

    public List<Recipe> getRecipes(List<RecipeCondition> recipeConditions)
    {
        ArrayList<Recipe> recipes = new ArrayList<>();
        DBARecipeIngredients ri = new DBARecipeIngredients(context);
        DBARecipeTags rt = new DBARecipeTags(context);
        int[] riIngredients = ri.recipesByCondition(recipeConditions);
        int[] riTags = rt.recipesByCondition(recipeConditions);
        int[] ris;
        int i = 0, j = 0, counter = 0;
        if(riIngredients.length == 0)
            ris = riTags;
        else if(riTags.length == 0)
            ris = riIngredients;
        else if(riIngredients.length > 0 && riTags.length > 0)
        {
            while (i<riIngredients.length)
            {
                if(j == riTags.length)
                {
                    i++;
                    j = 0;
                }
                else if(riIngredients[i] == riTags[j])
                {
                    counter++;
                    i++;
                    j = 0;
                }
                else
                {
                    j++;
                }
            }
            ris = new int[counter];
            while (i<riIngredients.length)
            {
                if(j == riTags.length)
                {
                    i++;
                    j = 0;
                }
                else if(riIngredients[i] == riTags[j])
                {
                    ris[ris.length - counter--] = riIngredients[i];
                    i++;
                    j = 0;
                }
                else
                {
                    j++;
                }
            }
        }
        else ris = new int[0];
        String query = String.format("SELECT * FROM %s WHERE %s=?", Recipes.TABLE, Recipes.COLUMN_ID);
        for (int id : ris)
        {
            Cursor cursor = database.rawQuery(query, new String[]{ String.valueOf(id)});
            if (cursor.moveToFirst()){
                long userId = cursor.getLong(cursor.getColumnIndex(Recipes.COLUMN_USER_ID));
                String name = cursor.getString(cursor.getColumnIndex(Recipes.COLUMN_NAME));
                long ttc = cursor.getLong(cursor.getColumnIndex(Recipes.COLUMN_TIME_TO_COOK));
                String text = cursor.getString(cursor.getColumnIndex(Recipes.COLUMN_TEXT));
                long likes = cursor.getLong(cursor.getColumnIndex(Recipes.COLUMN_LIKES));
                long uv = cursor.getLong(cursor.getColumnIndex(Recipes.COLUMN_USER_VISIBLE));
                recipes.add(new Recipe(id, userId, name, ttc, text, likes, uv));
            }
            cursor.close();
        }
        return recipes;
    }

    public List<Recipe> getRecipes(){
        ArrayList<Recipe> recipes = new ArrayList<>();
        Cursor cursor = getAllEntries();
        while (cursor.moveToNext()){
            long id = cursor.getLong(cursor.getColumnIndex(Recipes.COLUMN_ID));
            long userId = cursor.getLong(cursor.getColumnIndex(Recipes.COLUMN_USER_ID));
            String name = cursor.getString(cursor.getColumnIndex(Recipes.COLUMN_NAME));
            long ttc = cursor.getLong(cursor.getColumnIndex(Recipes.COLUMN_TIME_TO_COOK));
            String text = cursor.getString(cursor.getColumnIndex(Recipes.COLUMN_TEXT));
            long likes = cursor.getLong(cursor.getColumnIndex(Recipes.COLUMN_LIKES));
            long uv = cursor.getLong(cursor.getColumnIndex(Recipes.COLUMN_USER_VISIBLE));
            recipes.add(new Recipe(id, userId, name, ttc, text, likes, uv));
        }
        cursor.close();
        return recipes;
    }

    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, Recipes.TABLE);
    }

    public Recipe getRecipe(long id){
        Recipe recipe = null;
        String query = String.format("SELECT * FROM %s WHERE %s=?", Recipes.TABLE, Recipes.COLUMN_ID);
        Cursor cursor = database.rawQuery(query, new String[]{ String.valueOf(id)});
        if(cursor.moveToFirst()){
            long userId = cursor.getInt(cursor.getColumnIndex(Recipes.COLUMN_USER_ID));
            String name = cursor.getString(cursor.getColumnIndex(Recipes.COLUMN_NAME));
            long ttc = cursor.getInt(cursor.getColumnIndex(Recipes.COLUMN_TIME_TO_COOK));
            String text = cursor.getString(cursor.getColumnIndex(Recipes.COLUMN_TEXT));
            long likes = cursor.getInt(cursor.getColumnIndex(Recipes.COLUMN_LIKES));
            long uv = cursor.getInt(cursor.getColumnIndex(Recipes.COLUMN_USER_VISIBLE));
            recipe = new Recipe(id, userId, name, ttc, text, likes, uv);
        }
        cursor.close();
        return recipe;
    }

    public long insert(Recipe recipe){

        ContentValues cv = new ContentValues();
        cv.put(Recipes.COLUMN_USER_ID, recipe.getUserId());
        cv.put(Recipes.COLUMN_NAME, recipe.getName());
        cv.put(Recipes.COLUMN_TIME_TO_COOK, recipe.getTTC());
        cv.put(Recipes.COLUMN_TEXT, recipe.getText());
        cv.put(Recipes.COLUMN_LIKES, recipe.getLikes());
        cv.put(Recipes.COLUMN_USER_VISIBLE, recipe.getUV());

        return database.insert(Recipes.TABLE, null, cv);
    }

    public long delete(long Id){

        String whereClause = "Id = ?";
        String[] whereArgs = new String[]{String.valueOf(Id)};
        return database.delete(Recipes.TABLE, whereClause, whereArgs);
    }

    public long update(Recipe recipe){

        String whereClause = Recipes.COLUMN_ID + "=" + String.valueOf(recipe.getId());
        ContentValues cv = new ContentValues();
        cv.put(Recipes.COLUMN_USER_ID, recipe.getUserId());
        cv.put(Recipes.COLUMN_NAME, recipe.getName());
        cv.put(Recipes.COLUMN_TIME_TO_COOK, recipe.getTTC());
        cv.put(Recipes.COLUMN_TEXT, recipe.getText());
        cv.put(Recipes.COLUMN_LIKES, recipe.getLikes());
        cv.put(Recipes.COLUMN_USER_VISIBLE, recipe.getUV());
        return database.update(Recipes.TABLE, cv, whereClause, null);
    }
}