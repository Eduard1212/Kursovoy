package com.example.whatook.DBH;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DBAUserNotifications {

    private DBHUserNotifications dbHelper;
    private SQLiteDatabase database;

    public DBAUserNotifications(Context context){
        dbHelper = new DBHUserNotifications(context.getApplicationContext());
    }

    public DBAUserNotifications open(){
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        dbHelper.close();
    }

    private Cursor getAllEntries(){
        String[] columns = new String[] {DBHUserNotifications.COLUMN_ID, DBHUserNotifications.COLUMN_USER_ID, DBHUserNotifications.COLUMN_NOTIFICATION_ID};
        return  database.query(DBHUserNotifications.TABLE, columns, null, null, null, null, null);
    }

    public List<UserNotification> getUserNotifications(long userId){
        ArrayList<UserNotification> un = new ArrayList<>();
        String query = String.format("SELECT * FROM %s WHERE %s=?", DBHUserNotifications.TABLE, DBHUserNotifications.COLUMN_USER_ID);
        Cursor cursor = database.rawQuery(query, new String[]{ String.valueOf(userId)});
        while (cursor.moveToNext()){
            long id = cursor.getLong(cursor.getColumnIndex(DBHUserNotifications.COLUMN_ID));
            long notificationId = cursor.getLong(cursor.getColumnIndex(DBHUserNotifications.COLUMN_NOTIFICATION_ID));
            un.add(new UserNotification(id, userId, notificationId));
        }
        cursor.close();
        return un;
    }

    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, DBHUserNotifications.TABLE);
    }

    public long insert(UserNotification un){

        ContentValues cv = new ContentValues();
        cv.put(DBHUserNotifications.COLUMN_USER_ID, un.getUserId());
        cv.put(DBHUserNotifications.COLUMN_NOTIFICATION_ID, un.getNotificationId());

        return database.insert(DBHUserNotifications.TABLE, null, cv);
    }

    public long delete(long Id){

        String whereClause = "Id = ?";
        String[] whereArgs = new String[]{String.valueOf(Id)};
        return database.delete(DBHUserNotifications.TABLE, whereClause, whereArgs);
    }
}