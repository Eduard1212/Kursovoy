package com.example.whatook.DBH;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

public class DBAUsers {

    private Users dbHelper;
    private SQLiteDatabase database;

    public DBAUsers(Context context){
        dbHelper = new Users(context.getApplicationContext());
    }

    public DBAUsers open(){
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        dbHelper.close();
    }

    private Cursor getAllEntries(){
        String[] columns = new String[] {Users.COLUMN_ID, Users.COLUMN_ROLE_ID, Users.COLUMN_USERNAME, Users.COLUMN_MAIL,
                Users.COLUMN_PASSWORD, Users.COLUMN_AVATAR};
        return database.query(Users.TABLE, columns, null, null, null, null, null);
    }

    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, Users.TABLE);
    }

    public User getUser(long id){
        User user = null;
        String query = String.format("SELECT * FROM %s WHERE %s=?", Users.TABLE, Users.COLUMN_ID);
        Cursor cursor = database.rawQuery(query, new String[]{ String.valueOf(id)});
        if(cursor.moveToFirst()){
            long roleId = cursor.getLong(cursor.getColumnIndex(Users.COLUMN_ROLE_ID));
            String username = cursor.getString(cursor.getColumnIndex(Users.COLUMN_USERNAME));
            String mail = cursor.getString(cursor.getColumnIndex(Users.COLUMN_MAIL));
            String password = cursor.getString(cursor.getColumnIndex(Users.COLUMN_PASSWORD));
            String avatar = cursor.getString(cursor.getColumnIndex(Users.COLUMN_AVATAR));
            user = new User(id, roleId, username, mail, password, avatar);
        }
        cursor.close();
        return user;
    }

    public User getUser(String username, String pass){
        User user = null;
        String query = String.format("SELECT * FROM %s WHERE %s=? AND %s=?", Users.TABLE, Users.COLUMN_USERNAME, Users.COLUMN_PASSWORD);
        Cursor cursor = database.rawQuery(query, new String[]{ username, pass });
        if(cursor.moveToFirst()){
            long id = cursor.getLong(cursor.getColumnIndex(Users.COLUMN_ID));
            long roleId = cursor.getLong(cursor.getColumnIndex(Users.COLUMN_ROLE_ID));
            String mail = cursor.getString(cursor.getColumnIndex(Users.COLUMN_MAIL));
            String avatar = cursor.getString(cursor.getColumnIndex(Users.COLUMN_AVATAR));
            user = new User(id, roleId, username, mail, pass, avatar);
        }
        cursor.close();
        return user;
    }

    public long insert(User user){

        ContentValues cv = new ContentValues();
        cv.put(Users.COLUMN_ROLE_ID, user.getRoleId());
        cv.put(Users.COLUMN_USERNAME, user.getName());
        cv.put(Users.COLUMN_MAIL, user.getMail());
        cv.put(Users.COLUMN_PASSWORD, user.getPass());
        cv.put(Users.COLUMN_AVATAR, user.getAvatar());

        return database.insert(Users.TABLE, null, cv);
    }

    public long delete(long Id){

        String whereClause = "Id = ?";
        String[] whereArgs = new String[]{String.valueOf(Id)};
        return database.delete(Users.TABLE, whereClause, whereArgs);
    }

    public long update(User user){

        String whereClause = Users.COLUMN_ID + "=" + String.valueOf(user.getId());
        ContentValues cv = new ContentValues();
        cv.put(Users.COLUMN_ROLE_ID, user.getRoleId());
        cv.put(Users.COLUMN_USERNAME, user.getName());
        cv.put(Users.COLUMN_MAIL, user.getMail());
        cv.put(Users.COLUMN_PASSWORD, user.getPass());
        cv.put(Users.COLUMN_AVATAR, user.getAvatar());
        return database.update(Users.TABLE, cv, whereClause, null);
    }
}