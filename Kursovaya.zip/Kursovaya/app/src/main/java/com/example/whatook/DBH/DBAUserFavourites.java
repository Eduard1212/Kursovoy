package com.example.whatook.DBH;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DBAUserFavourites {

    private DBHUserFavourites dbHelper;
    private SQLiteDatabase database;

    public DBAUserFavourites(Context context){
        dbHelper = new DBHUserFavourites(context.getApplicationContext());
    }

    public DBAUserFavourites open(){
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        dbHelper.close();
    }

    private Cursor getAllEntries(){
        String[] columns = new String[] {DBHUserFavourites.COLUMN_ID, DBHUserFavourites.COLUMN_USER_ID, DBHUserFavourites.COLUMN_RECIPE_ID};
        return  database.query(DBHUserFavourites.TABLE, columns, null, null, null, null, null);
    }

    public List<UserFavourite> getUserFavourites(long userId){
        ArrayList<UserFavourite> uf = new ArrayList<>();
        String query = String.format("SELECT * FROM %s WHERE %s=?", DBHUserFavourites.TABLE, DBHUserFavourites.COLUMN_USER_ID);
        Cursor cursor = database.rawQuery(query, new String[]{ String.valueOf(userId)});
        while (cursor.moveToNext()){
            long id = cursor.getLong(cursor.getColumnIndex(DBHUserFavourites.COLUMN_ID));
            long recipeId = cursor.getLong(cursor.getColumnIndex(DBHUserFavourites.COLUMN_RECIPE_ID));
            uf.add(new UserFavourite(id, userId, recipeId));
        }
        cursor.close();
        return uf;
    }

    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, DBHUserFavourites.TABLE);
    }

    public long insert(UserFavourite uf){

        ContentValues cv = new ContentValues();
        cv.put(DBHUserFavourites.COLUMN_USER_ID, uf.getUserId());
        cv.put(DBHUserFavourites.COLUMN_RECIPE_ID, uf.getRecipeId());

        return database.insert(DBHUserFavourites.TABLE, null, cv);
    }
}