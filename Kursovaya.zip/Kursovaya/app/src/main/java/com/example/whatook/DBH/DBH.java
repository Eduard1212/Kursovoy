package com.example.whatook.DBH;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBH {
    private static String DB_NAME = "Whatook.db";
    private static final int SCHEMA = 1;

    public static class Actions extends SQLiteOpenHelper {

        static final String TABLE = "Actions";
        static final String COLUMN_ID = "Id";
        static final String COLUMN_NAME = "Name";

        Actions(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_NAME + " TEXT NOT NULL)");
            // добавление начальных данных
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('закрыл доступ к рецепту для пользователей');");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('проверил рецепт');");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class Ingredients extends SQLiteOpenHelper {

        static final String TABLE = "Ingredients"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_NAME = "Name";

        Ingredients(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_NAME+ " TEXT NOT NULL)");
            // добавление начальных данных
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Вода');");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Сахар');");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Соль');");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Картофель');");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Морковь');");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Масло');");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class Logs extends SQLiteOpenHelper {

        static final String TABLE = "Logs"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_USER_ID = "UserId";
        static final String COLUMN_ACTION_ID = "ActionId";
        static final String COLUMN_RECIPE_ID = "RecipeId";
        static final String COLUMN_TIME = "Time";

        Logs(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_USER_ID + " INTEGER NOT NULL, "
                    + COLUMN_ACTION_ID + " INTEGER NOT NULL, "
                    + COLUMN_RECIPE_ID + " INTEGER NOT NULL, "
                    + COLUMN_TIME + " TEXT NOT NULL)");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class Notifications extends SQLiteOpenHelper {

        static final String TABLE = "Notifications"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_TEXT = "Text";
        static final String COLUMN_DATE = "Date";

        Notifications(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_TEXT + " TEXT NOT NULL, "
                    + COLUMN_DATE + " TEXT NOT NULL)");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class RecipeIngredients extends SQLiteOpenHelper {

        static final String TABLE = "RecipeIngredients"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_RECIPE_ID = "RecipeId";
        static final String COLUMN_INGREDIENT_ID = "IngredientId";
        static final String COLUMN_AMOUNT = "Amount";

        RecipeIngredients(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_RECIPE_ID + " INTEGER NOT NULL, "
                    + COLUMN_INGREDIENT_ID + " INTEGER NOT NULL, "
                    + COLUMN_AMOUNT + " INTEGER NOT NULL)");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class RecipePics extends SQLiteOpenHelper {

        static final String TABLE = "RecipePics"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_RECIPE_ID = "RecipeId";
        static final String COLUMN_PIC_NAME = "PicName";

        RecipePics(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_RECIPE_ID + " INTEGER NOT NULL, "
                    + COLUMN_PIC_NAME + " TEXT NOT NULL)");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class RecipeTags extends SQLiteOpenHelper {

        static final String TABLE = "RecipeTags"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_RECIPE_ID = "RecipeId";
        static final String COLUMN_TAG_ID = "TagId";

        RecipeTags(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_RECIPE_ID + " INTEGER NOT NULL, "
                    + COLUMN_TAG_ID + " INTEGER NOT NULL)");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class Recipes extends SQLiteOpenHelper {

        static final String TABLE = "Recipes"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_USER_ID = "UserId";
        static final String COLUMN_NAME = "Name";
        static final String COLUMN_TIME_TO_COOK = "TimeToCook";
        static final String COLUMN_TEXT = "Text";
        static final String COLUMN_LIKES = "Likes";
        static final String COLUMN_USER_VISIBLE = "UserVisible";

        Recipes(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_USER_ID + " INTEGER NOT NULL, "
                    + COLUMN_NAME + " TEXT NOT NULL, "
                    + COLUMN_TIME_TO_COOK + " INTEGER NOT NULL, "
                    + COLUMN_TEXT + " TEXT NOT NULL, "
                    + COLUMN_LIKES + " INTEGER NOT NULL, "
                    + COLUMN_USER_VISIBLE + " INTEGER NOT NULL)");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class Roles extends SQLiteOpenHelper {

        static final String TABLE = "Roles"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_NAME = "Name";

        Roles(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_NAME + " TEXT NOT NULL)");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Админ');");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Модератор');");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Пользователь');");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class Tags extends SQLiteOpenHelper {

        static final String TABLE = "Tags"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_NAME = "Name";

        Tags(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_NAME + " TEXT NOT NULL)");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Лето');");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Острое');");
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME + ") VALUES ('Холодное');");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class UserFavourites extends SQLiteOpenHelper {

        static final String TABLE = "UserFavourites"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_USER_ID = "UserId";
        static final String COLUMN_RECIPE_ID = "RecipeId";

        UserFavourites(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_USER_ID + " INTEGER NOT NULL, "
                    + COLUMN_RECIPE_ID + " INTEGER NOT NULL)");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class UserNotifications extends SQLiteOpenHelper {

        static final String TABLE = "UserNotifications"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_USER_ID = "UserId";
        static final String COLUMN_NOTIFICATION_ID = "NotificationId";

        UserNotifications(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_USER_ID + " INTEGER NOT NULL, "
                    + COLUMN_NOTIFICATION_ID + " INTEGER NOT NULL)");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public static class UserSubscriptions extends SQLiteOpenHelper {

        static final String TABLE = "UserSubscriptions"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_USER_ID = "UserId";
        static final String COLUMN_SUBSCRIBER_ID = "SubscriberId";

        UserSubscriptions(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_USER_ID + " INTEGER NOT NULL, "
                    + COLUMN_SUBSCRIBER_ID + " INTEGER NOT NULL)");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }

    public class Users extends SQLiteOpenHelper {

        static final String TABLE = "Users"; // название таблицы в бд
        // названия столбцов
        static final String COLUMN_ID = "Id";
        static final String COLUMN_ROLE_ID = "RoleId";
        static final String COLUMN_USERNAME = "Username";
        static final String COLUMN_MAIL = "Mail";
        static final String COLUMN_PASSWORD = "Password";
        static final String COLUMN_AVATAR = "Avatar";

        Users(Context context) {
            super(context, DB_NAME, null, SCHEMA);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE " + TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_ROLE_ID + " INTEGER NOT NULL, " + COLUMN_USERNAME + " TEXT NOT NULL UNIQUE, " + COLUMN_MAIL + " TEXT NOT NULL UNIQUE, "
                    + COLUMN_PASSWORD + " TEXT NOT NULL, " + COLUMN_AVATAR + " TEXT)");
            // добавление начальных данных
            db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_ROLE_ID + ", " + COLUMN_USERNAME + ", " + COLUMN_MAIL + ", "
                    + COLUMN_PASSWORD + ") VALUES (2, 'Eduard', '123@mail.ru', '123');");
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE);
            onCreate(db);
        }
    }


}
